<?php
/*
Plugin Name: Certificate Verification
Description: A plugin to verify student certificates using a shortcode, with separate admin management.
Version: 1.9.14
Author: Md Rumen Husen
Author URI: https://github.com/rumenhusen
Requires at least: 5.0
Requires PHP: 7.4
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check PHP version
if (version_compare(PHP_VERSION, '7.4', '<')) {
    add_action('admin_notices', function() {
        echo '<div class="error"><p>Certificate Verification requires PHP 7.4 or higher. Your server is running PHP ' . esc_html(PHP_VERSION) . '. Please upgrade your PHP version.</p></div>';
    });
    return;
}

// Check WordPress version
global $wp_version;
if (version_compare($wp_version, '5.0', '<')) {
    add_action('admin_notices', function() use ($wp_version) {
        echo '<div class="error"><p>Certificate Verification requires WordPress 5.0 or higher. Your site is running WordPress ' . esc_html($wp_version) . '. Please upgrade WordPress.</p></div>';
    });
    return;
}

// Define plugin constants
define('CV_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CV_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CV_DEBUG_LOG', WP_CONTENT_DIR . '/cv-debug.log');

// Safely initialize debug log file
if (!file_exists(CV_DEBUG_LOG)) {
    if (is_writable(WP_CONTENT_DIR)) {
        @file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Debug log initialized.\n");
    } else {
        add_action('admin_notices', function() {
            echo '<div class="error"><p>Certificate Verification: Cannot write to wp-content directory. Debug logging disabled.</p></div>';
        });
    }
}

// Add custom rewrite rule for verification URLs
add_action('init', 'cv_add_rewrite_rules');
function cv_add_rewrite_rules() {
    add_rewrite_rule(
        '^verify/([^/]+)/?$',
        'index.php?cv_verify=1&certificate_id=$matches[1]',
        'top'
    );
}

// Add query vars for the rewrite rule
add_filter('query_vars', 'cv_add_query_vars');
function cv_add_query_vars($vars) {
    $vars[] = 'cv_verify';
    $vars[] = 'certificate_id';
    return $vars;
}

// Create the certificate-verified page on plugin activation
register_activation_hook(__FILE__, 'cv_create_verification_page');
function cv_create_verification_page() {
    $page = get_page_by_path('certificate-verified');
    if (!$page) {
        $page_data = array(
            'post_title'   => 'Certificate Verified',
            'post_content' => '',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_name'    => 'certificate-verified',
        );
        $page_id = wp_insert_post($page_data);
        if (is_writable(CV_DEBUG_LOG)) {
            if ($page_id) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Created certificate-verified page with ID: $page_id\n", FILE_APPEND);
            } else {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Failed to create certificate-verified page\n", FILE_APPEND);
            }
        }
    }

    cv_add_rewrite_rules();
    flush_rewrite_rules();
}

// Handle the custom verification URL
add_action('template_redirect', 'cv_handle_verification_url');
function cv_handle_verification_url() {
    if (get_query_var('cv_verify')) {
        $certificate_id = get_query_var('certificate_id');
        if ($certificate_id) {
            global $wpdb;
            $student_table = $wpdb->prefix . 'cv_student_certificates';

            $certificate = $wpdb->get_row($wpdb->prepare(
                "SELECT *, 'student' as certificate_type FROM $student_table WHERE certificate_id = %s",
                $certificate_id
            ));

            if ($certificate) {
                $redirect_url = add_query_arg(
                    array(
                        'certificate_id' => urlencode($certificate->certificate_id),
                        'type' => $certificate->certificate_type,
                    ),
                    site_url('/certificate-verified')
                );
                wp_redirect($redirect_url);
                exit;
            } else {
                global $wp_query;
                $wp_query->set_404();
                status_header(404);
                include(get_404_template());
                exit;
            }
        }
    }
}

// Enqueue styles and scripts
function cv_enqueue_assets() {
    $css_file = CV_PLUGIN_DIR . 'assets/css/tm-styles.css';
    $js_file = CV_PLUGIN_DIR . 'assets/js/tm-scripts.js';

    static $logged_missing_files = false;

    if (!file_exists($css_file) || !file_exists($js_file)) {
        if (!$logged_missing_files && is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Missing CSS/JS files in assets directory.\n", FILE_APPEND);
            $logged_missing_files = true;
        }
        return;
    }

    // Enqueue Google Fonts (Roboto)
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap', array(), null);

    // Enqueue Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css', array(), '5.15.4');

    if (!wp_style_is('cv-styles', 'registered')) {
        wp_enqueue_style('cv-styles', CV_PLUGIN_URL . 'assets/css/tm-styles.css', array(), '1.9.14', 'all');
    }
    
    if (!wp_script_is('cv-scripts', 'registered')) {
        wp_enqueue_script('cv-scripts', CV_PLUGIN_URL . 'assets/js/tm-scripts.js', array('jquery'), '1.9.14', true);
        
        wp_localize_script('cv-scripts', 'cv_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cv_verify_nonce'),
            'share_base_url_facebook' => 'https://www.facebook.com/sharer/sharer.php?u=',
            'share_base_url_linkedin' => 'https://www.linkedin.com/sharing/share-offsite/?url=',
            'site_url' => site_url(),
        ));
    }
}
add_action('wp_enqueue_scripts', 'cv_enqueue_assets');

// Include certificate classes with error handling
$required_files = [
    'includes/class-certificate-verification-student-certificates.php'
];

foreach ($required_files as $file) {
    if (file_exists(CV_PLUGIN_DIR . $file)) {
        require_once CV_PLUGIN_DIR . $file;
    } else {
        add_action('admin_notices', function() use ($file) {
            echo '<div class="error"><p>Certificate Verification: Missing required file: ' . esc_html($file) . '</p></div>';
        });
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Missing file: $file\n", FILE_APPEND);
        }
        return;
    }
}

// Initialize the plugin
function cv_init() {
    try {
        $student_certificates = new Certificate_Verification_Student_Certificates();
        $student_certificates->register();

        global $wpdb;
        $student_table = $wpdb->prefix . 'cv_student_certificates';
        $course_links_table = $wpdb->prefix . 'cv_course_links';

        $student_table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $student_table)) === $student_table;
        $course_links_table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $course_links_table)) === $course_links_table;

        if (!$student_table_exists || !$course_links_table_exists) {
            add_action('admin_notices', function() {
                $url = wp_nonce_url(admin_url('admin.php?page=cv-certificates&action=create_tables'), 'cv_create_tables');
                echo '<div class="error"><p>Certificate Verification: One or more database tables are missing. <a href="' . esc_url($url) . '">Click here to create them.</a></p></div>';
            });
        }

        if ($student_table_exists) {
            $columns = $wpdb->get_results("SHOW COLUMNS FROM $student_table");
            $column_names = array_column($columns, 'Field');
            if (!in_array('total_credits', $column_names)) {
                $result = $wpdb->query("ALTER TABLE $student_table ADD COLUMN total_credits INT NOT NULL DEFAULT 0");
                if ($result === false) {
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Failed to add total_credits column to $student_table: " . $wpdb->last_error . "\n", FILE_APPEND);
                    }
                }
            }
            if (!in_array('course_url', $column_names)) {
                $result = $wpdb->query("ALTER TABLE $student_table ADD COLUMN course_url TEXT DEFAULT NULL");
                if ($result === false) {
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Failed to add course_url column to $student_table: " . $wpdb->last_error . "\n", FILE_APPEND);
                    }
                } else {
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Successfully added course_url column to $student_table.\n", FILE_APPEND);
                    }
                }
            }
            if (!in_array('fathers_name', $column_names)) {
                $result = $wpdb->query("ALTER TABLE $student_table ADD COLUMN fathers_name VARCHAR(100) DEFAULT NULL");
                if ($result === false) {
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Failed to add fathers_name column to $student_table: " . $wpdb->last_error . "\n", FILE_APPEND);
                    }
                } else {
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Successfully added fathers_name column to $student_table.\n", FILE_APPEND);
                    }
                }
            }
        }

        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Plugin initialized successfully. Tables checked - Student: " . ($student_table_exists ? 'Exists' : 'Missing') . ", Course Links: " . ($course_links_table_exists ? 'Exists' : 'Missing') . "\n", FILE_APPEND);
        }
    } catch (Exception $e) {
        add_action('admin_notices', function() use ($e) {
            echo '<div class="error"><p>Certificate Verification: Initialization failed - ' . esc_html($e->getMessage()) . '</p></div>';
        });
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Initialization failed: " . $e->getMessage() . "\n", FILE_APPEND);
        }
    }
}
add_action('plugins_loaded', 'cv_init');

// Create tables on plugin activation or version update
function cv_create_tables() {
    $student_certificates = new Certificate_Verification_Student_Certificates();
    $student_certificates->create_table();

    cv_create_course_links_table();

    update_option('cv_version', '1.9.14');

    if (is_writable(CV_DEBUG_LOG)) {
        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Tables creation attempted on plugin activation/update.\n", FILE_APPEND);
    }
}
register_activation_hook(__FILE__, 'cv_create_tables');

// Check version and create tables if needed
add_action('plugins_loaded', 'cv_check_version');
function cv_check_version() {
    $current_version = get_option('cv_version', '0');
    if (version_compare($current_version, '1.9.14', '<')) {
        cv_create_tables();
    }
}

// Manual table creation via admin action
add_action('admin_init', 'cv_handle_manual_table_creation');
function cv_handle_manual_table_creation() {
    if (isset($_GET['page']) && $_GET['page'] === 'cv-certificates' && isset($_GET['action']) && $_GET['action'] === 'create_tables') {
        if (!check_admin_referer('cv_create_tables')) {
            wp_die('Security check failed.');
        }

        cv_create_tables();

        wp_redirect(admin_url('admin.php?page=cv-certificates'));
        exit;
    }
}

// Create table for course links
function cv_create_course_links_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'cv_course_links';
    $charset_collate = $wpdb->get_charset_collate();

    if (is_writable(CV_DEBUG_LOG)) {
        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Creating course links table with prefix: " . $wpdb->prefix . "\n", FILE_APPEND);
    }

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        course_name VARCHAR(100) NOT NULL,
        course_url TEXT NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY course_name (course_name)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $result = dbDelta($sql);

    if ($wpdb->last_error) {
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course links table creation failed: " . $wpdb->last_error . "\n", FILE_APPEND);
        }
        add_action('admin_notices', function() use ($wpdb) {
            echo '<div class="error"><p>Certificate Verification: Failed to create course links table - ' . esc_html($wpdb->last_error) . '</p></div>';
        });
    } else {
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course links table created or verified successfully.\n", FILE_APPEND);
        }
    }
}

// Shortcode for certificate verification
function cv_verifier_shortcode() {
    if (!is_page() && !is_single()) {
        return '<p>Error: This shortcode can only be used on pages or posts.</p>';
    }

    ob_start();
    ?>
    <div class="cv-certificate-verifier">
        <h2>Certificate Verification</h2>
        <form id="cv-certificate-verifier-form" method="post">
            <label for="certificate-id">Certificate ID:</label>
            <input type="text" id="certificate-id" name="certificate_id" placeholder="e.g., CV00001" required maxlength="50">
            <button type="submit">Verify Certificate</button>
        </form>
        <div id="cv-verification-result"></div>
        <div id="cv-verification-share" style="display: none;">
            <button class="cv-share-button" data-platform="facebook"><i class="fab fa-facebook-f"></i> Share on Facebook</button>
            <button class="cv-share-button" data-platform="linkedin"><i class="fab fa-linkedin-in"></i> Share on LinkedIn</button>
            <button class="cv-share-button" id="cv-copy-link"><i class="fas fa-link"></i> Copy Link</button>
            <span id="cv-copy-message" style="display: none;">Link copied!</span>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('cv_certificate_verifier', 'cv_verifier_shortcode');

// AJAX handler for certificate verification
function cv_verify_certificate() {
    if (!check_ajax_referer('cv_verify_nonce', 'nonce', false)) {
        wp_send_json_error(array('message' => 'Security check failed.'));
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Verification failed: Invalid nonce.\n", FILE_APPEND);
        }
        return;
    }

    if (!isset($_POST['certificate_id']) || empty($_POST['certificate_id'])) {
        wp_send_json_error(array('message' => 'Certificate ID is required.'));
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Verification failed: Missing certificate ID.\n", FILE_APPEND);
        }
        return;
    }

    $certificate_id = sanitize_text_field($_POST['certificate_id']);
    global $wpdb;

    $student_table = $wpdb->prefix . 'cv_student_certificates';
    $certificate = $wpdb->get_row($wpdb->prepare(
        "SELECT *, 'student' as certificate_type FROM $student_table WHERE certificate_id = %s",
        $certificate_id
    ));

    if ($certificate) {
        $verification_url = site_url('/verify/' . urlencode($certificate->certificate_id));

        $response = array(
            'message' => 'Certificate Verified!',
            'details' => array(
                'certificate_id' => $certificate->certificate_id,
                'certificate_type' => ucfirst($certificate->certificate_type),
                'student_name' => $certificate->student_name,
                'course_name' => $certificate->course_name,
                'issue_date' => $certificate->issue_date,
                'verification_url' => $verification_url,
            ),
        );

        if ($certificate->certificate_type === 'student') {
            $response['details']['fathers_name'] = $certificate->fathers_name;
            $response['details']['total_credits'] = $certificate->total_credits;
            $response['details']['course_url'] = $certificate->course_url;
        }

        wp_send_json_success($response);
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Verification successful for ID: $certificate_id\n", FILE_APPEND);
        }
    } else {
        wp_send_json_error(array(
            'message' => 'Certificate Not Found.',
        ));
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Verification failed: Certificate not found (ID: $certificate_id).\n", FILE_APPEND);
        }
    }
}
add_action('wp_ajax_cv_verify_certificate', 'cv_verify_certificate');
add_action('wp_ajax_nopriv_cv_verify_certificate', 'cv_verify_certificate');

// Handle the verification result page (for copied link)
add_action('init', 'cv_handle_verification_result_page');
function cv_handle_verification_result_page() {
    if (isset($_GET['certificate_id']) && isset($_GET['type'])) {
        $certificate_id = sanitize_text_field($_GET['certificate_id']);
        $type = sanitize_text_field($_GET['type']);
        global $wpdb;

        // Check if the certificate-verified page exists
        $page = get_page_by_path('certificate-verified');
        if (!$page) {
            if (is_writable(CV_DEBUG_LOG)) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Certificate-verified page does not exist. Please create a page with the slug 'certificate-verified'.\n", FILE_APPEND);
            }
            wp_die('Certificate verification page not found. Please create a page with the slug "certificate-verified".');
        }

        if ($type === 'student') {
            $table_name = $wpdb->prefix . 'cv_student_certificates';
        } else {
            return;
        }

        $certificate = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE certificate_id = %s",
            $certificate_id
        ));

        if ($certificate) {
            add_filter('wp_title', function() use ($certificate) {
                return 'Certificate Verification Result: ' . esc_html($certificate->certificate_id);
            });
            add_filter('the_content', function($content) use ($certificate, $type) {
                $output = '<div class="cv-certificate-verifier">';
                $output .= '<h2>Certificate Verification Result</h2>';
                $output .= '<p><strong>Certificate ID:</strong> ' . esc_html($certificate->certificate_id) . '</p>';
                $output .= '<p><strong>Type:</strong> ' . esc_html(ucfirst($type)) . '</p>';
                $output .= '<p><strong>Name:</strong> ' . esc_html($certificate->student_name) . '</p>';

                if ($type === 'student') {
                    $fathers_name = isset($certificate->fathers_name) && !empty($certificate->fathers_name) ? esc_html($certificate->fathers_name) : 'N/A';
                    $output .= '<p><strong>Father\'s Name:</strong> ' . $fathers_name . '</p>';
                    $output .= '<p><strong>Course Name:</strong> ' . esc_html($certificate->course_name) . '</p>';
                    if ($certificate->course_url) {
                        $output .= '<p><strong>Course Details:</strong> <a href="' . esc_url($certificate->course_url) . '" target="_blank">' . esc_html($certificate->course_url) . '</a></p>';
                    } else {
                        $output .= '<p><strong>Course Details:</strong> N/A</p>';
                    }
                    $output .= '<p><strong>Issue Date:</strong> ' . esc_html($certificate->issue_date) . '</p>';
                    $output .= '<p><strong>Total Credits:</strong> ' . esc_html($certificate->total_credits) . '</p>';
                }

                $output .= '</div>';
                return $output;
            });
        }
    }
}