<?php
if (!defined('ABSPATH')) {
    exit;
}

class Certificate_Verification_Student_Certificates {
    public function register() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        // Start output buffering early to capture any unexpected output
        add_action('init', array($this, 'start_output_buffering'), 1);
    }

    // Start output buffering early in the WordPress lifecycle
    public function start_output_buffering() {
        if (!ob_get_level()) { // Check if buffering is already active to avoid nesting
            ob_start();
        }
    }

    // Create database table for student certificates
    public function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'cv_student_certificates';
        $charset_collate = $wpdb->get_charset_collate();

        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Creating student certificates table with prefix: " . $wpdb->prefix . "\n", FILE_APPEND);
        }

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            certificate_id VARCHAR(50) NOT NULL,
            student_name VARCHAR(100) NOT NULL,
            course_name VARCHAR(100) NOT NULL,
            issue_date DATE NOT NULL,
            total_credits INT NOT NULL DEFAULT 0,
            course_url TEXT DEFAULT NULL,
            fathers_name VARCHAR(100) DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY certificate_id (certificate_id),
            UNIQUE KEY student_father_unique (student_name, fathers_name)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $result = dbDelta($sql);

        if ($wpdb->last_error) {
            if (is_writable(CV_DEBUG_LOG)) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Student certificates table creation failed: " . $wpdb->last_error . "\n", FILE_APPEND);
            }
            add_action('admin_notices', function() use ($wpdb) {
                echo '<div class="error"><p>Certificate Verification: Failed to create student certificates table - ' . esc_html($wpdb->last_error) . '</p></div>';
            });
        } else {
            if (is_writable(CV_DEBUG_LOG)) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Student certificates table created or verified successfully.\n", FILE_APPEND);
            }
        }
    }

    // Check if table exists
    private function table_exists($table_name) {
        global $wpdb;
        $query = $wpdb->prepare("SHOW TABLES LIKE %s", $table_name);
        $result = $wpdb->get_var($query);
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Checking if table $table_name exists: " . ($result === $table_name ? 'Yes' : 'No') . "\n", FILE_APPEND);
        }
        return $result === $table_name;
    }

    // Add admin menu
    public function add_admin_menu() {
        add_menu_page(
            'Certificates',
            'Certificates',
            'manage_options',
            'cv-certificates',
            array($this, 'admin_page'),
            'dashicons-awards',
            30
        );
        add_submenu_page(
            'cv-certificates',
            'Student Certificates',
            'Student Certificates',
            'manage_options',
            'cv-certificates',
            array($this, 'admin_page')
        );
        add_submenu_page(
            'cv-certificates',
            'Manage Course Links',
            'Manage Course Links',
            'manage_options',
            'cv-course-links',
            array($this, 'course_links_page')
        );
        add_submenu_page(
            'cv-certificates',
            'Certificate ID Settings',
            'Certificate ID Settings',
            'manage_options',
            'cv-certificate-id-settings',
            array($this, 'certificate_id_settings_page')
        );
    }

    // Register settings
    public function register_settings() {
        register_setting('cv_student_certificates_group', 'cv_student_certificate_data', array($this, 'sanitize_data'));
        register_setting('cv_course_links_group', 'cv_course_link_data', array($this, 'sanitize_course_link_data'));
        register_setting('cv_certificate_id_settings_group', 'cv_certificate_id_generation', array($this, 'sanitize_certificate_id_setting'));
    }

    // Sanitize input data for certificates
    public function sanitize_data($input) {
        $sanitized = array();
        $sanitized['certificate_id'] = sanitize_text_field($input['certificate_id']);
        $sanitized['student_name'] = sanitize_text_field($input['student_name']);
        $sanitized['course_name'] = sanitize_text_field($input['course_name']);
        $sanitized['issue_date'] = sanitize_text_field($input['issue_date']);
        $sanitized['total_credits'] = absint($input['total_credits']);
        $sanitized['course_url'] = !empty($input['course_url']) ? esc_url_raw($input['course_url']) : null;
        $sanitized['fathers_name'] = !empty($input['fathers_name']) ? sanitize_text_field($input['fathers_name']) : null;
        return $sanitized;
    }

    // Sanitize input data for course links
    public function sanitize_course_link_data($input) {
        $sanitized = array();
        $sanitized['course_name'] = sanitize_text_field($input['course_name']);
        $sanitized['course_url'] = esc_url_raw($input['course_url']);
        return $sanitized;
    }

    // Sanitize certificate ID generation setting
    public function sanitize_certificate_id_setting($input) {
        return in_array($input, array('automatic', 'manual')) ? $input : 'manual'; // Default to manual if invalid
    }

    // Check for duplicate certificate ID
    private function check_duplicate_certificate($certificate_id, $exclude_id = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'cv_student_certificates';

        $query = $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE certificate_id = %s",
            $certificate_id
        );
        if ($exclude_id) {
            $query .= $wpdb->prepare(" AND certificate_id != %s", $exclude_id);
        }

        $count = $wpdb->get_var($query);
        if ($wpdb->last_error) {
            if (is_writable(CV_DEBUG_LOG)) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Error during duplicate check for ID $certificate_id: " . $wpdb->last_error . "\n", FILE_APPEND);
            }
        }
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Duplicate check for student ID: $certificate_id, Count: $count\n", FILE_APPEND);
        }
        return $count > 0;
    }

    // Check for duplicate student name and father's name combination
    private function check_duplicate_student_and_father($student_name, $fathers_name, $exclude_id = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'cv_student_certificates';

        // If fathers_name is empty, treat it as NULL in the query
        if (empty($fathers_name)) {
            $query = $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE student_name = %s AND fathers_name IS NULL",
                $student_name
            );
        } else {
            $query = $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE student_name = %s AND fathers_name = %s",
                $student_name,
                $fathers_name
            );
        }

        if ($exclude_id) {
            $query .= $wpdb->prepare(" AND certificate_id != %s", $exclude_id);
        }

        $count = $wpdb->get_var($query);
        if ($wpdb->last_error) {
            if (is_writable(CV_DEBUG_LOG)) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Error during duplicate check for student name $student_name and father's name $fathers_name: " . $wpdb->last_error . "\n", FILE_APPEND);
            }
        }
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Duplicate check for student name: $student_name and father's name: $fathers_name, Count: $count\n", FILE_APPEND);
        }
        return $count > 0;
    }

    // Generate a random certificate ID
    private function generate_random_certificate_id() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'cv_student_certificates';
        $prefix = 'CV';
        $random_id = '';
        $max_attempts = 100; // Prevent infinite loops
        $attempt = 0;

        do {
            $attempt++;
            if ($attempt > $max_attempts) {
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Failed to generate unique certificate ID after $max_attempts attempts.\n", FILE_APPEND);
                }
                wp_die('Error: Unable to generate a unique certificate ID. Please try again or switch to manual entry.');
            }

            $random_number = sprintf("%06d", mt_rand(1, 999999)); // Generate a 6-digit random number
            $random_id = $prefix . $random_number;
        } while ($this->check_duplicate_certificate($random_id));

        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Generated unique certificate ID: $random_id after $attempt attempts.\n", FILE_APPEND);
        }
        return $random_id;
    }

    // Certificate ID Settings page
    public function certificate_id_settings_page() {
        ?>
        <div class="wrap">
            <h1>Certificate ID Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('cv_certificate_id_settings_group');
                do_settings_sections('cv_certificate_id_settings_group');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="cv_certificate_id_generation">Certificate ID Generation</label></th>
                        <td>
                            <select name="cv_certificate_id_generation" id="cv_certificate_id_generation">
                                <option value="manual" <?php selected(get_option('cv_certificate_id_generation', 'manual'), 'manual'); ?>>Manual</option>
                                <option value="automatic" <?php selected(get_option('cv_certificate_id_generation', 'manual'), 'automatic'); ?>>Automatic</option>
                            </select>
                            <p class="description">Choose how certificate IDs are generated when adding new certificates. "Automatic" will generate random IDs, while "Manual" allows you to enter them.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>
        </div>
        <?php
    }

    // Admin page for managing student certificates
    public function admin_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'cv_student_certificates';
        $course_links_table = $wpdb->prefix . 'cv_course_links';

        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Accessing Student Certificates admin page. Table name: $table_name\n", FILE_APPEND);
        }

        // Check the certificate ID generation setting
        $certificate_id_generation = get_option('cv_certificate_id_generation', 'manual');
        $auto_generate_id = ($certificate_id_generation === 'automatic');
        $generated_certificate_id = $auto_generate_id ? $this->generate_random_certificate_id() : '';

        // Handle form submission for adding/editing
        if (isset($_POST['submit_certificate']) && check_admin_referer('cv_save_certificate', 'cv_nonce')) {
            // Log all form data for debugging
            if (is_writable(CV_DEBUG_LOG)) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Form submitted with data: " . json_encode($_POST) . "\n", FILE_APPEND);
            }

            $certificate_id = $auto_generate_id ? $generated_certificate_id : sanitize_text_field($_POST['certificate_id']);
            $student_name = sanitize_text_field($_POST['student_name']);
            $fathers_name = !empty($_POST['fathers_name']) ? sanitize_text_field($_POST['fathers_name']) : null;
            $exclude_id = isset($_POST['certificate_id_hidden']) && !empty($_POST['certificate_id_hidden']) ? sanitize_text_field($_POST['certificate_id_hidden']) : '';

            // Validate inputs
            $error_message = '';
            if (empty($certificate_id) || empty($student_name) || empty($_POST['course_name_dropdown'])) {
                $error_message = 'Error: Certificate ID, Student Name, and Course Name are required.';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Validation failed: Missing required fields (certificate_id, student_name, course_name_dropdown).\n", FILE_APPEND);
                }
            } elseif (!$auto_generate_id && !preg_match('/^[a-zA-Z0-9-]+$/', $certificate_id)) {
                $error_message = 'Error: Certificate ID can only contain letters, numbers, and hyphens.';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Validation failed: Invalid certificate ID format.\n", FILE_APPEND);
                }
            } elseif (strlen($certificate_id) > 50) {
                $error_message = 'Error: Certificate ID is too long (max 50 characters).';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Validation failed: Certificate ID too long.\n", FILE_APPEND);
                }
            } elseif ($this->check_duplicate_certificate($certificate_id, $exclude_id)) {
                $error_message = 'Error: Certificate ID already exists. Please use a unique ID.';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Validation failed: Duplicate certificate ID ($certificate_id).\n", FILE_APPEND);
                }
            } elseif ($this->check_duplicate_student_and_father($student_name, $fathers_name, $exclude_id)) {
                $error_message = 'Error: A student with this name and father\'s name already exists. Please use a unique combination.';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Validation failed: Duplicate student name ($student_name) and father\'s name ($fathers_name).\n", FILE_APPEND);
                }
            } else {
                // Validate date formats
                $issue_date = sanitize_text_field($_POST['issue_date']);

                // Set a default issue_date if empty
                if (empty($issue_date)) {
                    $issue_date = date('Y-m-d'); // Default to current date
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Issue Date was empty, defaulted to $issue_date.\n", FILE_APPEND);
                    }
                }

                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $issue_date)) {
                    $error_message = 'Error: Invalid Issue Date format. Use YYYY-MM-DD.';
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Validation failed: Invalid Issue Date format ($issue_date).\n", FILE_APPEND);
                    }
                } elseif (!empty($fathers_name) && !preg_match('/^[a-zA-Z\s\'\-\.]+$/', $fathers_name)) {
                    $error_message = 'Error: Invalid Father\'s Name format. Use letters, spaces, hyphens, apostrophes, or periods only.';
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Validation failed: Invalid Father\'s Name format ($fathers_name).\n", FILE_APPEND);
                    }
                } else {
                    // Check if table exists
                    if (!$this->table_exists($table_name)) {
                        $this->create_table();
                        if (!$this->table_exists($table_name)) {
                            $error_message = 'Error: Database table does not exist and could not be created.';
                            if (is_writable(CV_DEBUG_LOG)) {
                                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Failed to create table $table_name on demand.\n", FILE_APPEND);
                            }
                        }
                    }

                    if (empty($error_message)) {
                        $data = array(
                            'certificate_id' => $certificate_id,
                            'student_name' => $student_name,
                            'course_name' => sanitize_text_field($_POST['course_name_dropdown']),
                            'issue_date' => $issue_date,
                            'total_credits' => absint($_POST['total_credits']),
                            'course_url' => !empty($_POST['course_details']) ? esc_url_raw($_POST['course_details']) : null,
                            'fathers_name' => $fathers_name,
                        );

                        if (is_writable(CV_DEBUG_LOG)) {
                            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Attempting to save student certificate: " . json_encode($data) . "\n", FILE_APPEND);
                        }

                        if ($exclude_id) {
                            // Update existing certificate
                            $result = $wpdb->update(
                                $table_name,
                                $data,
                                array('certificate_id' => $exclude_id),
                                array('%s', '%s', '%s', '%s', '%d', '%s', '%s'),
                                array('%s')
                            );
                            if ($result === false) {
                                $error_message = 'Error: Failed to update certificate. Check debug log for details.';
                                if (is_writable(CV_DEBUG_LOG)) {
                                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Update failed: " . $wpdb->last_error . "\n", FILE_APPEND);
                                }
                            } else {
                                if (is_writable(CV_DEBUG_LOG)) {
                                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Student certificate updated successfully (ID: $certificate_id).\n", FILE_APPEND);
                                }
                                // Store success message in transient
                                set_transient('cv_success_message', 'Certificate updated successfully.', 30);
                                $redirect_url = admin_url('admin.php?page=cv-certificates');
                                // Try PHP redirect
                                if (ob_get_level()) {
                                    ob_end_clean();
                                }
                                if (!headers_sent()) {
                                    wp_redirect($redirect_url);
                                    exit;
                                } else {
                                    // Fallback to JavaScript redirect with a slight delay
                                    echo '<script>setTimeout(function() { window.location.href="' . esc_url($redirect_url) . '"; }, 100);</script>';
                                    echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_url($redirect_url) . '"></noscript>';
                                    exit;
                                }
                            }
                        } else {
                            // Insert new certificate
                            $result = $wpdb->insert(
                                $table_name,
                                $data,
                                array('%s', '%s', '%s', '%s', '%d', '%s', '%s')
                            );
                            if ($result === false) {
                                $error_message = 'Error: Failed to add certificate. Check debug log for details.';
                                if (is_writable(CV_DEBUG_LOG)) {
                                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Insert failed: " . $wpdb->last_error . "\n", FILE_APPEND);
                                }
                            } else {
                                if (is_writable(CV_DEBUG_LOG)) {
                                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Student certificate added successfully (ID: $certificate_id).\n", FILE_APPEND);
                                }
                                // Store success message in transient
                                set_transient('cv_success_message', 'Certificate added successfully.', 30);
                                $redirect_url = admin_url('admin.php?page=cv-certificates');
                                // Try PHP redirect
                                if (ob_get_level()) {
                                    ob_end_clean();
                                }
                                if (!headers_sent()) {
                                    wp_redirect($redirect_url);
                                    exit;
                                } else {
                                    // Fallback to JavaScript redirect with a slight delay
                                    echo '<script>setTimeout(function() { window.location.href="' . esc_url($redirect_url) . '"; }, 100);</script>';
                                    echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_url($redirect_url) . '"></noscript>';
                                    exit;
                                }
                            }
                        }
                    }
                }
            }
        }

        // Handle bulk delete
        if (isset($_POST['bulk_action']) && $_POST['bulk_action'] === 'delete' && isset($_POST['certificate_ids']) && is_array($_POST['certificate_ids']) && check_admin_referer('cv_bulk_action', 'cv_bulk_nonce')) {
            $certificate_ids = array_map('sanitize_text_field', $_POST['certificate_ids']);
            $deleted = 0;
            foreach ($certificate_ids as $certificate_id) {
                $result = $wpdb->delete($table_name, array('certificate_id' => $certificate_id));
                if ($result !== false) {
                    $deleted++;
                }
            }
            if (is_writable(CV_DEBUG_LOG)) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Bulk deleted $deleted student certificates.\n", FILE_APPEND);
            }
            // Store success message in transient
            set_transient('cv_success_message', 'Certificates deleted successfully.', 30);
            $redirect_url = admin_url('admin.php?page=cv-certificates');
            // Try PHP redirect
            if (ob_get_level()) {
                ob_end_clean();
            }
            if (!headers_sent()) {
                wp_redirect($redirect_url);
                exit;
            } else {
                // Fallback to JavaScript redirect with a slight delay
                echo '<script>setTimeout(function() { window.location.href="' . esc_url($redirect_url) . '"; }, 100);</script>';
                echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_url($redirect_url) . '"></noscript>';
                exit;
            }
        }

        // Delete single certificate
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['certificate_id'])) {
            $certificate_id = sanitize_text_field($_GET['certificate_id']);
            $nonce = isset($_GET['_wpnonce']) ? $_GET['_wpnonce'] : '';
            if (wp_verify_nonce($nonce, 'cv_delete_' . $certificate_id)) {
                $result = $wpdb->delete($table_name, array('certificate_id' => $certificate_id));
                if ($result !== false) {
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Deleted student certificate (ID: $certificate_id).\n", FILE_APPEND);
                    }
                    // Store success message in transient
                    set_transient('cv_success_message', 'Certificate deleted successfully.', 30);
                    $redirect_url = admin_url('admin.php?page=cv-certificates');
                    // Try PHP redirect
                    if (ob_get_level()) {
                        ob_end_clean();
                    }
                    if (!headers_sent()) {
                        wp_redirect($redirect_url);
                        exit;
                    } else {
                        // Fallback to JavaScript redirect with a slight delay
                        echo '<script>setTimeout(function() { window.location.href="' . esc_url($redirect_url) . '"; }, 100);</script>';
                        echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_url($redirect_url) . '"></noscript>';
                        exit;
                    }
                } else {
                    $error_message = 'Error: Failed to delete certificate.';
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Delete failed for student certificate (ID: $certificate_id): " . $wpdb->last_error . "\n", FILE_APPEND);
                    }
                }
            } else {
                $error_message = 'Security check failed for deletion.';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Delete failed: Invalid nonce for ID $certificate_id.\n", FILE_APPEND);
                }
            }
        }

        // Initialize messages
        $error_message = isset($error_message) ? $error_message : '';
        $success_message = '';

        // Retrieve success message from transient
        $transient_message = get_transient('cv_success_message');
        if ($transient_message) {
            $success_message = $transient_message;
            delete_transient('cv_success_message');
        }

        // Edit certificate - fetch data for editing
        $edit_certificate = null;
        if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['certificate_id'])) {
            $certificate_id = sanitize_text_field($_GET['certificate_id']);
            $nonce = isset($_GET['_wpnonce']) ? $_GET['_wpnonce'] : '';
            if (wp_verify_nonce($nonce, 'cv_edit_' . $certificate_id)) {
                $edit_certificate = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $table_name WHERE certificate_id = %s",
                    $certificate_id
                ));
                if (!$edit_certificate) {
                    $error_message = 'Error: Certificate not found for editing.';
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Edit failed: Student certificate not found (ID: $certificate_id).\n", FILE_APPEND);
                    }
                }
            } else {
                $error_message = 'Security check failed for editing.';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Edit failed: Invalid nonce for ID $certificate_id.\n", FILE_APPEND);
                }
            }
        }

        // Search and filter
        $search_query = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        $filter_date_from = isset($_GET['filter_date_from']) ? sanitize_text_field($_GET['filter_date_from']) : '';
        $filter_date_to = isset($_GET['filter_date_to']) ? sanitize_text_field($_GET['filter_date_to']) : '';

        // Build the query
        $query = "SELECT * FROM $table_name WHERE 1=1";
        $query_params = array();

        if ($search_query) {
            $query .= " AND (certificate_id LIKE %s OR student_name LIKE %s OR course_name LIKE %s)";
            $like = '%' . $wpdb->esc_like($search_query) . '%';
            $query_params[] = $like;
            $query_params[] = $like;
            $query_params[] = $like;
        }

        if ($filter_date_from) {
            $query .= " AND issue_date >= %s";
            $query_params[] = $filter_date_from;
        }

        if ($filter_date_to) {
            $query .= " AND issue_date <= %s";
            $query_params[] = $filter_date_to;
        }

        $certificates = $wpdb->get_results($wpdb->prepare($query, $query_params));
        if ($wpdb->last_error) {
            if (is_writable(CV_DEBUG_LOG)) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Query failed: " . $wpdb->last_error . "\n", FILE_APPEND);
            }
        }

        // Fetch course links for dropdowns
        $course_links = $wpdb->get_results("SELECT * FROM $course_links_table ORDER BY course_name ASC");
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Fetched " . count($course_links) . " course links for dropdown.\n", FILE_APPEND);
        }
        if (empty($course_links)) {
            $error_message = 'Warning: No courses found in Manage Course Links. Please add a course first.';
            if (is_writable(CV_DEBUG_LOG)) {
                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - No course links found in $course_links_table.\n", FILE_APPEND);
            }
        }

        // Output the page content
        ?>
        <div class="wrap">
            <h1>Student Certificates</h1>
            <?php if ($error_message): ?>
                <div class="notice notice-error"><p><?php echo esc_html($error_message); ?></p></div>
            <?php endif; ?>
            <?php if ($success_message): ?>
                <div class="notice notice-success"><p><?php echo esc_html($success_message); ?></p></div>
            <?php endif; ?>
            <h2><?php echo $edit_certificate ? 'Edit Certificate' : 'Add New Certificate'; ?></h2>
            <form method="post" action="">
                <?php wp_nonce_field('cv_save_certificate', 'cv_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="certificate_id">Certificate ID</label></th>
                        <td>
                            <?php if ($edit_certificate): ?>
                                <input type="text" name="certificate_id" id="certificate_id" value="<?php echo esc_attr($edit_certificate->certificate_id); ?>" readonly>
                                <input type="hidden" name="certificate_id_hidden" value="<?php echo esc_attr($edit_certificate->certificate_id); ?>">
                            <?php elseif ($auto_generate_id): ?>
                                <input type="text" name="certificate_id" id="certificate_id" value="<?php echo esc_attr($generated_certificate_id); ?>" readonly>
                                <p class="description">Certificate ID is automatically generated.</p>
                            <?php else: ?>
                                <input type="text" name="certificate_id" id="certificate_id" value="" required maxlength="50" pattern="[a-zA-Z0-9-]+">
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="student_name">Student Name</label></th>
                        <td><input type="text" name="student_name" id="student_name" value="<?php echo $edit_certificate ? esc_attr($edit_certificate->student_name) : ''; ?>" required maxlength="100"></td>
                    </tr>
                    <tr>
                        <th><label for="fathers_name">Father's Name</label></th>
                        <td><input type="text" name="fathers_name" id="fathers_name" value="<?php echo $edit_certificate ? esc_attr($edit_certificate->fathers_name) : ''; ?>"></td>
                    </tr>
                    <tr>
                        <th><label for="course_name_dropdown">Course Name</label></th>
                        <td>
                            <select name="course_name_dropdown" id="course_name_dropdown" required>
                                <option value="">Select a Course Name</option>
                                <?php foreach ($course_links as $link) : ?>
                                    <option value="<?php echo esc_attr($link->course_name); ?>" <?php selected($edit_certificate && $edit_certificate->course_name === $link->course_name); ?>>
                                        <?php echo esc_html($link->course_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="course_details">Course Details</label></th>
                        <td>
                            <select name="course_details" id="course_details">
                                <option value="">Select a Course Link (Optional)</option>
                                <?php foreach ($course_links as $link) : ?>
                                    <option value="<?php echo esc_url($link->course_url); ?>" <?php selected($edit_certificate && $edit_certificate->course_url === $link->course_url); ?>>
                                        <?php echo esc_html($link->course_url); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <input type="hidden" name="course_url" id="course_url" value="<?php echo $edit_certificate ? esc_attr($edit_certificate->course_url) : ''; ?>">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="issue_date">Issue Date</label></th>
                        <td><input type="date" name="issue_date" id="issue_date" value="<?php echo $edit_certificate ? esc_attr($edit_certificate->issue_date) : ''; ?>" required></td>
                    </tr>
                    <tr>
                        <th><label for="total_credits">Total Credits</label></th>
                        <td><input type="number" name="total_credits" id="total_credits" value="<?php echo $edit_certificate ? esc_attr($edit_certificate->total_credits) : '0'; ?>" min="0" required></td>
                    </tr>
                </table>
                <?php submit_button($edit_certificate ? 'Update Certificate' : 'Add Certificate', 'primary', 'submit_certificate'); ?>
            </form>

            <h2>Existing Student Certificates</h2>
            <form method="get" action="">
                <input type="hidden" name="page" value="cv-certificates">
                <p class="search-box">
                    <label class="screen-reader-text" for="certificate-search-input">Search Certificates:</label>
                    <input type="search" id="certificate-search-input" name="s" value="<?php echo esc_attr($search_query); ?>">
                    <input type="submit" id="search-submit" class="button" value="Search Certificates">
                </p>
                <p>
                    <label for="filter_date_from">From Date:</label>
                    <input type="date" id="filter_date_from" name="filter_date_from" value="<?php echo esc_attr($filter_date_from); ?>">
                    <label for="filter_date_to">To Date:</label>
                    <input type="date" id="filter_date_to" name="filter_date_to" value="<?php echo esc_attr($filter_date_to); ?>">
                    <input type="submit" class="button" value="Filter">
                </p>
            </form>
            <form method="post" action="">
                <?php wp_nonce_field('cv_bulk_action', 'cv_bulk_nonce'); ?>
                <div class="tablenav top">
                    <div class="alignleft actions">
                        <select name="bulk_action">
                            <option value="">Bulk Actions</option>
                            <option value="delete">Delete</option>
                        </select>
                        <input type="submit" class="button action" value="Apply">
                    </div>
                </div>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th class="check-column"><input type="checkbox" id="select-all"></th>
                            <th>Certificate ID</th>
                            <th>Student Name</th>
                            <th>Father's Name</th>
                            <th>Course Name</th>
                            <th>Course Details</th>
                            <th>Issue Date</th>
                            <th>Total Credits</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($certificates as $certificate) : ?>
                            <tr>
                                <th class="check-column"><input type="checkbox" name="certificate_ids[]" value="<?php echo esc_attr($certificate->certificate_id); ?>"></th>
                                <td><?php echo esc_html($certificate->certificate_id); ?></td>
                                <td><?php echo esc_html($certificate->student_name); ?></td>
                                <td><?php echo esc_html($certificate->fathers_name ?: 'N/A'); ?></td>
                                <td><?php echo esc_html($certificate->course_name); ?></td>
                                <td><?php echo $certificate->course_url ? '<a href="' . esc_url($certificate->course_url) . '" target="_blank">View Course</a>' : 'N/A'; ?></td>
                                <td><?php echo esc_html($certificate->issue_date); ?></td>
                                <td><?php echo esc_html($certificate->total_credits); ?></td>
                                <td>
                                    <a href="<?php echo esc_url(add_query_arg(array('action' => 'edit', 'certificate_id' => $certificate->certificate_id, '_wpnonce' => wp_create_nonce('cv_edit_' . $certificate->certificate_id)))); ?>">Edit</a> |
                                    <a href="<?php echo esc_url(add_query_arg(array('action' => 'delete', 'certificate_id' => $certificate->certificate_id, '_wpnonce' => wp_create_nonce('cv_delete_' . $certificate->certificate_id)))); ?>" onclick="return confirm('Are you sure?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>
        </div>
        <script>
            jQuery(document).ready(function($) {
                $('#select-all').on('change', function() {
                    $('input[name="certificate_ids[]"]').prop('checked', $(this).prop('checked'));
                });

                // Update course_url when course_details is selected
                $('#course_details').on('change', function() {
                    var selectedUrl = $(this).val();
                    $('#course_url').val(selectedUrl);
                });
            });
        </script>
        <?php
    }

    // Admin page for managing course links
    public function course_links_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'cv_course_links';

        // Handle form submission for adding/editing course links
        $error_message = '';
        $success_message = '';
        if (isset($_POST['submit_course_link']) && check_admin_referer('cv_save_course_link', 'cv_course_nonce')) {
            $course_name = sanitize_text_field($_POST['course_name']);
            $course_url = esc_url_raw($_POST['course_url']);
            $exclude_id = isset($_POST['course_id_hidden']) && !empty($_POST['course_id_hidden']) ? absint($_POST['course_id_hidden']) : 0;

            // Validate inputs
            if (empty($course_name) || empty($course_url)) {
                $error_message = 'Error: Both course name and URL are required.';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link validation failed: Missing fields.\n", FILE_APPEND);
                }
            } elseif (strlen($course_name) > 100) {
                $error_message = 'Error: Course name is too long (max 100 characters).';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link validation failed: Course name too long.\n", FILE_APPEND);
                }
            } else {
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM $table_name WHERE course_name = %s" . ($exclude_id ? " AND id != %d" : ""),
                    $course_name,
                    $exclude_id
                ));

                if ($existing > 0) {
                    $error_message = 'Error: Course name already exists. Please use a unique name.';
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link validation failed: Duplicate course name ($course_name).\n", FILE_APPEND);
                    }
                } else {
                    $data = array(
                        'course_name' => $course_name,
                        'course_url' => $course_url,
                    );

                    if ($exclude_id) {
                        // Update existing course link
                        $result = $wpdb->update(
                            $table_name,
                            $data,
                            array('id' => $exclude_id),
                            array('%s', '%s'),
                            array('%d')
                        );
                        if ($result === false) {
                            $error_message = 'Error: Failed to update course link.';
                            if (is_writable(CV_DEBUG_LOG)) {
                                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link update failed: " . $wpdb->last_error . "\n", FILE_APPEND);
                            }
                        } else {
                            $success_message = 'Course link updated successfully.';
                            if (is_writable(CV_DEBUG_LOG)) {
                                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link updated successfully (ID: $exclude_id).\n", FILE_APPEND);
                            }
                        }
                    } else {
                        // Insert new course link
                        $result = $wpdb->insert(
                            $table_name,
                            $data,
                            array('%s', '%s')
                        );
                        if ($result === false) {
                            $error_message = 'Error: Failed to add course link.';
                            if (is_writable(CV_DEBUG_LOG)) {
                                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link insert failed: " . $wpdb->last_error . "\n", FILE_APPEND);
                            }
                        } else {
                            $success_message = 'Course link added successfully.';
                            if (is_writable(CV_DEBUG_LOG)) {
                                file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link added successfully.\n", FILE_APPEND);
                            }
                        }
                    }
                }
            }
        }

        // Delete course link
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['course_id'])) {
            $course_id = absint($_GET['course_id']);
            $nonce = isset($_GET['_wpnonce']) ? $_GET['_wpnonce'] : '';
            if (wp_verify_nonce($nonce, 'cv_delete_course_' . $course_id)) {
                $result = $wpdb->delete($table_name, array('id' => $course_id));
                if ($result !== false) {
                    $success_message = 'Course link deleted successfully.';
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link deleted (ID: $course_id).\n", FILE_APPEND);
                    }
                } else {
                    $error_message = 'Error: Failed to delete course link.';
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link delete failed (ID: $course_id): " . $wpdb->last_error . "\n", FILE_APPEND);
                    }
                }
            } else {
                $error_message = 'Security check failed for deletion.';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link delete failed: Invalid nonce for ID $course_id.\n", FILE_APPEND);
                }
            }
        }

        // Edit course link - fetch data for editing
        $edit_course_link = null;
        if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['course_id'])) {
            $course_id = absint($_GET['course_id']);
            $nonce = isset($_GET['_wpnonce']) ? $_GET['_wpnonce'] : '';
            if (wp_verify_nonce($nonce, 'cv_edit_course_' . $course_id)) {
                $edit_course_link = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $table_name WHERE id = %d",
                    $course_id
                ));
                if (!$edit_course_link) {
                    $error_message = 'Error: Course link not found for editing.';
                    if (is_writable(CV_DEBUG_LOG)) {
                        file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link edit failed: Not found (ID: $course_id).\n", FILE_APPEND);
                    }
                }
            } else {
                $error_message = 'Security check failed for editing.';
                if (is_writable(CV_DEBUG_LOG)) {
                    file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Course link edit failed: Invalid nonce for ID $course_id.\n", FILE_APPEND);
                }
            }
        }

        // Fetch all course links
        $course_links = $wpdb->get_results("SELECT * FROM $table_name ORDER BY course_name ASC");
        if (is_writable(CV_DEBUG_LOG)) {
            file_put_contents(CV_DEBUG_LOG, date('Y-m-d H:i:s') . " - Fetched " . count($course_links) . " course links for Manage Course Links page.\n", FILE_APPEND);
        }
        ?>
        <div class="wrap">
            <h1>Manage Course Links</h1>
            <?php if ($error_message): ?>
                <div class="notice notice-error"><p><?php echo esc_html($error_message); ?></p></div>
            <?php endif; ?>
            <?php if ($success_message): ?>
                <div class="notice notice-success"><p><?php echo esc_html($success_message); ?></p></div>
            <?php endif; ?>
            <h2><?php echo $edit_course_link ? 'Edit Course Link' : 'Add New Course Link'; ?></h2>
            <form method="post" action="">
                <?php wp_nonce_field('cv_save_course_link', 'cv_course_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="course_name">Course Name</label></th>
                        <td>
                            <input type="text" name="course_name" id="course_name" value="<?php echo $edit_course_link ? esc_attr($edit_course_link->course_name) : ''; ?>" required maxlength="100">
                            <?php if ($edit_course_link) : ?>
                                <input type="hidden" name="course_id_hidden" value="<?php echo esc_attr($edit_course_link->id); ?>">
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="course_url">Course URL</label></th>
                        <td><input type="url" name="course_url" id="course_url" value="<?php echo $edit_course_link ? esc_attr($edit_course_link->course_url) : ''; ?>" required></td>
                    </tr>
                </table>
                <?php submit_button($edit_course_link ? 'Update Course Link' : 'Add Course Link', 'primary', 'submit_course_link'); ?>
            </form>

            <h2>Existing Course Links</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Course Name</th>
                        <th>Course URL</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($course_links as $link) : ?>
                        <tr>
                            <td><?php echo esc_html($link->course_name); ?></td>
                            <td><a href="<?php echo esc_url($link->course_url); ?>" target="_blank"><?php echo esc_html($link->course_url); ?></a></td>
                            <td>
                                <a href="<?php echo esc_url(add_query_arg(array('action' => 'edit', 'course_id' => $link->id, '_wpnonce' => wp_create_nonce('cv_edit_course_' . $link->id)))); ?>">Edit</a> |
                                <a href="<?php echo esc_url(add_query_arg(array('action' => 'delete', 'course_id' => $link->id, '_wpnonce' => wp_create_nonce('cv_delete_course_' . $link->id)))); ?>" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}