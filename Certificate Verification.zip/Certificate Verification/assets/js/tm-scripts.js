jQuery(document).ready(function($) {
    $('#cv-certificate-verifier-form').on('submit', function(e) {
        e.preventDefault();
        var certificate_id = $('#certificate-id').val();
        var nonce = cv_ajax.nonce;

        // Add click animation to the button
        var $button = $(this).find('button[type="submit"]');
        $button.addClass('clicked');

        $('#cv-verification-result').html('');
        $('#cv-verification-share').hide();

        $.ajax({
            url: cv_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'cv_verify_certificate',
                certificate_id: certificate_id,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    var details = response.data.details;
                    var resultHtml = '<h3>' + response.data.message + '</h3>';
                    resultHtml += '<p><strong>Certificate ID:</strong> ' + details.certificate_id + '</p>';
                    resultHtml += '<p><strong>Type:</strong> ' + details.certificate_type + '</p>';
                    resultHtml += '<p><strong>Name:</strong> ' + details.student_name + '</p>';

                    if (details.certificate_type === 'Student') {
                        resultHtml += '<p><strong>Father\'s Name:</strong> ' + (details.fathers_name ? details.fathers_name : 'N/A') + '</p>';
                        resultHtml += '<p><strong>Course Name:</strong> ' + details.course_name + '</p>';
                        if (details.course_url) {
                            resultHtml += '<p><strong>Course Details:</strong> <a href="' + details.course_url + '" target="_blank">' + details.course_url + '</a></p>';
                        } else {
                            resultHtml += '<p><strong>Course Details:</strong> N/A</p>';
                        }
                        resultHtml += '<p><strong>Issue Date:</strong> ' + details.issue_date + '</p>';
                        resultHtml += '<p><strong>Total Credits:</strong> ' + details.total_credits + '</p>';
                    }

                    $('#cv-verification-result').html(resultHtml);
                    $('#cv-verification-share').show();
                    $('#cv-verification-share').data('verification-url', details.verification_url);
                } else {
                    $('#cv-verification-result').html('<p>' + response.data.message + '</p>');
                    $('#cv-verification-share').hide();
                }
            },
            error: function(xhr, status, error) {
                $('#cv-verification-result').html('<p>An error occurred while verifying the certificate. Please try again.</p>');
                $('#cv-verification-share').hide();
            }
        });
    });

    // Share on Facebook
    $('.cv-share-button[data-platform="facebook"]').on('click', function() {
        var verificationUrl = $('#cv-verification-share').data('verification-url');
        if (verificationUrl) {
            var url = cv_ajax.share_base_url_facebook + encodeURIComponent(verificationUrl);
            window.open(url, '_blank');
        }
    });

    // Share on LinkedIn
    $('.cv-share-button[data-platform="linkedin"]').on('click', function() {
        var verificationUrl = $('#cv-verification-share').data('verification-url');
        if (verificationUrl) {
            var url = cv_ajax.share_base_url_linkedin + encodeURIComponent(verificationUrl);
            window.open(url, '_blank');
        }
    });

    // Copy Link
    $('#cv-copy-link').on('click', function() {
        var $button = $(this);
        var verificationUrl = $('#cv-verification-share').data('verification-url');
        if (verificationUrl) {
            navigator.clipboard.writeText(verificationUrl).then(function() {
                $button.addClass('copied');
                $('#cv-copy-message').show();
                setTimeout(function() {
                    $('#cv-copy-message').hide();
                }, 2000);
            });
        }
    });
});